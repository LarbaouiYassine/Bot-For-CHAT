import torch
from models.seq2seq.encoder import encoder_factory
from models.seq2seq.decoder import decoder_factory
from models.seq2seq.model import Seq2SeqTrain, Seq2SeqPredict
from collections import OrderedDict


def learn_model_factory(args, metadata):
    encoder = encoder_factory(args, metadata)
    decoder = decoder_factory(args, metadata)
    return Seq2SeqTrain(encoder, decoder, metadata.vocab_size)


def connect_model_factory(args, metadata, model_path, field):
    learn_model = learn_model_factory(args, metadata)
    learn_model.load_state_dict(get_state_dict(args, model_path))
    return Seq2SeqPredict(learn_model.encoder, learn_model.decoder, field)


def get_state_dict(args, model_path):
    state_dict = torch.load(model_path, map_location=lambda storage, loc: storage)

    if args.cuda and args.multi_gpu:
        new_state_dict = OrderedDict()
        for k, v in state_dict.items():
            key = k[7:]  # remove "module."
            new_state_dict[key] = v
        return new_state_dict

    return state_dict
