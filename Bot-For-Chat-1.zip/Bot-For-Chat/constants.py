SOS_TOKEN = '<sos>'  
EOS_TOKEN = '<eos>'  
PAD_TOKEN = '<pad>'  
LSTM = 'LSTM'
GRU = 'GRU'
MODEL_FORMAT = "seq2seq-%d-%f-%f.pt"
MODEL_START_FORMAT = "seq2seq-%d"
